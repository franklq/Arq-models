
import React from 'react'

const Hero = () => {
  return (
    <section className="h-screen flex items-center justify-center bg-[url('https://images.unsplash.com/photo-1600585154340-be6161a56a0c')] bg-cover bg-center">
      <div className="bg-black bg-opacity-50 p-10 rounded-xl text-center text-white">
        <h2 className="text-4xl md:text-6xl font-bold mb-4">Innovative Architectural Designs</h2>
        <p className="mb-6">Shaping the future with modern and sustainable architecture.</p>
        <a href="#projects" className="bg-primary text-white px-6 py-3 rounded-full hover:bg-green-600">Explore Projects</a>
      </div>
    </section>
  )
}

export default Hero
