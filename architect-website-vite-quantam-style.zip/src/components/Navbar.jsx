
import React from 'react'

const Navbar = () => {
  return (
    <header className="bg-white shadow fixed w-full z-50">
      <div className="container mx-auto flex justify-between items-center py-4 px-6">
        <h1 className="text-2xl font-bold text-primary">ArchiVision</h1>
        <nav className="space-x-6 hidden md:block">
          <a href="#about" className="text-gray-600 hover:text-primary">About</a>
          <a href="#services" className="text-gray-600 hover:text-primary">Services</a>
          <a href="#projects" className="text-gray-600 hover:text-primary">Projects</a>
          <a href="#contact" className="text-gray-600 hover:text-primary">Contact</a>
        </nav>
      </div>
    </header>
  )
}

export default Navbar
