
import React from 'react'

const Footer = () => {
  return (
    <footer className="bg-secondary text-white py-6 text-center">
      <p>&copy; 2025 ArchiVision. All rights reserved.</p>
    </footer>
  )
}

export default Footer
