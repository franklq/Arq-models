
import React, { useState } from "react";
import { Link } from "react-router-dom";

const Navbar = ({ transparent }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className={`flex items-center justify-between flex-wrap p-6 ${transparent ? 'absolute top-0 left-0 w-full z-30 text-white' : 'bg-white shadow-md'}`}>
      <div className="flex items-center flex-shrink-0 mr-6">
        <Link to="/" className="font-bold text-2xl tracking-tight">
          Archi<span className="text-green-500">Vision</span>
        </Link>
      </div>
      <div className="block lg:hidden">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="flex items-center px-3 py-2 border rounded text-teal-200 border-teal-400 hover:text-white hover:border-white"
        >
          <svg className="fill-current h-3 w-3" viewBox="0 0 20 20">
            <title>Menu</title>
            <path d="M0 3h20v2H0V3zm0 6h20v2H0V9zm0 6h20v2H0v-2z" />
          </svg>
        </button>
      </div>
      <div className={`w-full ${isOpen ? "block" : "hidden"} flex-grow lg:flex lg:items-center lg:w-auto`}>
        <div className={`text-sm lg:flex-grow text-right lg:text-left ${transparent ? 'text-white' : 'text-gray-800'}`}>
          <Link to="/about" className="block mt-4 lg:inline-block lg:mt-0 hover:text-green-500 mr-4">
            About
          </Link>
          <Link to="/services" className="block mt-4 lg:inline-block lg:mt-0 hover:text-green-500 mr-4">
            Services
          </Link>
          <Link to="/projects" className="block mt-4 lg:inline-block lg:mt-0 hover:text-green-500 mr-4">
            Projects
          </Link>
          <Link to="/contact" className="block mt-4 lg:inline-block lg:mt-0 hover:text-green-500">
            Contact
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
