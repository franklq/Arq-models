
import React from 'react'

const Projects = () => {
  return (
    <section id="projects" className="container mx-auto px-6 py-20">
      <h3 className="text-3xl font-bold text-center text-secondary mb-8">Projects</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
        <img className="rounded-lg shadow" src="https://images.unsplash.com/photo-1600585154203-6ff6f58c8d0c" alt="Project 1"/>
        <img className="rounded-lg shadow" src="https://images.unsplash.com/photo-1600585154337-54c1d1c3f4b2" alt="Project 2"/>
        <img className="rounded-lg shadow" src="https://images.unsplash.com/photo-1600585154517-dae310c0b8d8" alt="Project 3"/>
      </div>
    </section>
  )
}

export default Projects
