
import React from 'react'

const About = () => {
  return (
    <section id="about" className="container mx-auto px-6 py-20">
      <h3 className="text-3xl font-bold text-center text-secondary mb-8">About Us</h3>
      <p className="text-gray-600 text-center max-w-3xl mx-auto">
        We are a modern architecture firm specializing in creating spaces that inspire. With a focus on sustainability and innovation, we bring your visions to life through design excellence.
      </p>
    </section>
  )
}

export default About
