
import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./pages/About";
import Services from "./pages/Services";
import Projects from "./pages/Projects";
import Contact from "./pages/Contact";
import Footer from "./components/Footer";

function Home() {
  return (
    <div className="font-sans text-gray-800">
      <div className="relative h-screen w-full">
        <div
          className="absolute inset-0 w-full h-full bg-cover bg-center z-0"
          style={{ backgroundImage: "url(/assets/hero-architecture.jpg)" }}
        ></div>

        <div className="absolute inset-0 w-full h-full bg-black bg-opacity-40 z-10"></div>

        <div className="absolute top-0 left-0 w-full z-20">
          <Navbar transparent />
        </div>

        <div className="relative z-30 flex items-center justify-center h-full text-white px-4">
          <Hero />
        </div>
      </div>

      <Footer />
    </div>
  );
}

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/services" element={<Services />} />
        <Route path="/projects" element={<Projects />} />
        <Route path="/contact" element={<Contact />} />
      </Routes>
    </Router>
  );
}

export default App;
