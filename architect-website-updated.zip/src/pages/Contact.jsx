
import React from 'react';
import Navbar from '../components/Navbar';
import Footer from '../components/Footer';

const Contact = () => {
  return (
    <div className="flex flex-col min-h-screen font-sans text-gray-800">
      <Navbar />
      <main className="flex-grow flex items-center justify-center p-8 bg-gray-100">
        <h1 className="text-4xl font-bold">Contact Page</h1>
      </main>
      <Footer />
    </div>
  );
}

export default Contact;
